package co.assip.erp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssipErpBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssipErpBackendApplication.class, args);
	}

}

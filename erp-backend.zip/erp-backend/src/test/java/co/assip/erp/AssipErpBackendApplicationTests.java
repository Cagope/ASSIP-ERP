package co.assip.erp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssipErpBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}

package co.assip.erp.assip_erp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssipErpApplicationTests {

	@Test
	void contextLoads() {
	}

}

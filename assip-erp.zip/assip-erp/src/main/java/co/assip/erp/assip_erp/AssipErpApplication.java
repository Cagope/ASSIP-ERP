package co.assip.erp.assip_erp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssipErpApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssipErpApplication.class, args);
	}

}
